import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindWalletAccountComponent } from './find-wallet-account.component';

describe('FindWalletAccountComponent', () => {
  let component: FindWalletAccountComponent;
  let fixture: ComponentFixture<FindWalletAccountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindWalletAccountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindWalletAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
