import { Component, OnInit } from '@angular/core';
import { WalletService } from '../wallet.service';
import { Router, ActivatedRoute } from '@angular/router';
import { WalletAccount } from '../WalletAccount';

@Component({
  selector: 'app-find-wallet-account',
  templateUrl: './find-wallet-account.component.html',
  styleUrls: ['./find-wallet-account.component.css']
})
export class FindWalletAccountComponent implements OnInit {
  

  accountId : number;
  account : WalletAccount=new WalletAccount();

  constructor(private service:WalletService,private router : Router,private route: ActivatedRoute) {
    this.accountId=this.route.snapshot.params['accountId'];
    console.log(this.accountId);
    service.findWalletAccountById(this.accountId).subscribe(data=>this.account=data);
   }

  

  ngOnInit(): void {
    
  }

}
