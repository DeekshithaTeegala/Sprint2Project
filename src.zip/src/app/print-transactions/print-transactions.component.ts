import { Component, OnInit } from '@angular/core';
import { WalletService } from '../wallet.service';
import { WalletTransactions } from '../WalletTransactions';
import { WalletAccount } from '../WalletAccount';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-print-transactions',
  templateUrl: './print-transactions.component.html',
  styleUrls: ['./print-transactions.component.css']
})
export class PrintTransactionsComponent implements OnInit {

  flag:boolean=false;
  arr:WalletTransactions[]=[];
  arra : Observable<WalletTransactions[]>;
  transaction : WalletTransactions = new WalletTransactions();
  accountId:any;

  constructor(private service:WalletService) {
       this.accountId=sessionStorage.getItem("user");

    //  service.printAllTransactions(this.accountId).subscribe(data=>{this.arr=data;console.log(data);},error => alert(error.error.errorMessage));

    }

  printAllTransactions(accountId : number) : Observable<WalletTransactions[]>
  {
      this.service.printAllTransactions(this.accountId).subscribe(data=>this.arr=data,error => alert(error.error.errorMessage));

      this.arra=this.service.printAllTransactions(this.accountId);
      this.flag=true;
      return this.arra;
  }

  ngOnInit(): void {
    this.printAllTransactions(this.accountId);
  }

} 
