import { WalletTransactions } from './WalletTransactions';

export class WalletAccount
{
accountId:any;
accountBal:number;
status:string;
 transactions:WalletTransactions[];
}