import { WalletAccount } from './WalletAccount';

export class WalletTransactions{
    transactionId:number;
    description:string;
    accountBal:number;
    amount:number;
    dateOfTransaction:Date;

    walletAccount : WalletAccount=new WalletAccount();
}