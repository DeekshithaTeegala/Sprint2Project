import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintTransactionsComponent } from './print-transactions/print-transactions.component';
import { ViewAllAccountsComponent } from './view-all-accounts/view-all-accounts.component';
import { FindWalletAccountComponent } from './find-wallet-account/find-wallet-account.component';
import { LoginComponent } from './login/login.component';
import { AuthguardService } from './authguard.service';


const routes: Routes = [
  {
    path : 'login',
    component : LoginComponent
   },
  {
    path : 'withdraw',
    component : WithdrawComponent,
    canActivate : [AuthguardService]
   },
   {
    path : 'fund-transfer',
    component : FundTransferComponent,
    canActivate : [AuthguardService]
   },
   {
    path : 'print-transactions',
    component : PrintTransactionsComponent,
    canActivate : [AuthguardService]
   },
  
   {
     path : 'find-account/:accountId',
     component : FindWalletAccountComponent
   },
   {
    path : '',
    redirectTo : '/login',
    pathMatch : 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
