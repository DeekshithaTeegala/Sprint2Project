import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpResponse, HttpClient } from '@angular/common/http';
import { WalletTransactions } from './WalletTransactions';
import { WalletAccount } from './WalletAccount';
import { Login } from './login';

@Injectable({
  providedIn: 'root'
})
export class WalletService {
  url='http://localhost:9092/walletAccount/';



  constructor(private http:HttpClient) { }

  findUserLogin(username: string,password :string) : Observable<Login>{
    return this.http.get<Login >("http://localhost:9092/admin/login/"+username+"/"+password);
  }
  
  getAllAccounts() : Observable<WalletAccount []>{
    return this.http.get<WalletAccount[]>("http://localhost:9092/walletAccount");
  }

  printAllTransactions(accountId : number) : Observable<WalletTransactions[]> {
    return this.http.get<WalletTransactions[]>("http://localhost:9092/walletTransactions/"+accountId);
  }

  fundTransfer(accountId1: number,accountId2 :number,amount :number) : Observable<WalletAccount>{
    return this.http.put<WalletAccount>("http://localhost:9092/walletAccount/id/"+accountId1+"/id/"+accountId2+"/amount/"+amount,null);
  }
  
  withdraw(accountId : number,amount :number) : Observable<WalletAccount > {
    return this.http.put<WalletAccount>("http://localhost:9092/walletAccount/id/"+accountId+"/amount/"+amount,null);
  }

  findWalletAccountById(accountId:number)
  {
    return this.http.get<WalletAccount>("http://localhost:9092/walletAccount/"+accountId);
  }
}
