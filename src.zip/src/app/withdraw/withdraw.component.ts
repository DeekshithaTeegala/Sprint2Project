import { Component, OnInit } from '@angular/core';
import { WalletService } from '../wallet.service';
import { Observable } from 'rxjs';
import { WalletAccount } from '../WalletAccount';
import { WalletTransactions } from '../WalletTransactions';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  flag : boolean=false;
  
  accountId: any;
  amount : number;
  walletaccount : Observable<WalletAccount> ;
  account : WalletAccount = new WalletAccount();
  transaction : WalletTransactions=new WalletTransactions();
  
  constructor(private service : WalletService,private router:Router) {

    this.transaction.walletAccount.accountId=sessionStorage.getItem("user");
    //this.service.withdraw(this.accountId,this.amount).subscribe(data=>this.account=data);this.reloadData();
   
   }

   withdraw(accountId : number,amount : number) 
   {
     console.log(accountId);
     console.log(amount);
     this.service.withdraw(accountId,amount).subscribe(data => this.router.navigate(['find-account',accountId]),
          error => alert(error.error.errorMessage));
    // this.service.withdraw(accountId,amount).subscribe(data => this.account=>data );;
    //  this.flag=true;  
   }
 
   

   reloadData()
   {
     this.walletaccount=this.service.withdraw(this.accountId,this.amount);
   }
  ngOnInit(): void {
    this.withdraw(this.accountId,this.amount);
  }

}
