import { Component, OnInit } from '@angular/core';
import { WalletService } from '../wallet.service';
import { WalletAccount } from '../WalletAccount';
import { WalletTransactions } from '../WalletTransactions';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  
  flag : boolean=false;
  accountId1 : any;
  accountId2 : any;
  amount : number ;
  account : WalletAccount;
  
  walletAccount : Observable<WalletAccount>;
  transaction1 : WalletTransactions=new WalletTransactions();
  transaction2 : WalletTransactions=new WalletTransactions();
  
  constructor(private service : WalletService,private router : Router) { 
    this.transaction1.walletAccount.accountId=sessionStorage.getItem("user");

    // this.service.fundTransfer(this.accountId1,this.accountId2,this.amount).subscribe(data=> this.account= data);
}

  fundTransfer(accountId1 : number,accountId2 : number,amount : number)
  {
    this.service.fundTransfer(accountId1,accountId2,amount).subscribe(data=>this.router.navigate(['find-account',accountId1]),
         error => alert(error.error.errorMessage));
    
    // this.flag=true;
  }

  

  ngOnInit(): void {
      this.fundTransfer(this.accountId1,this.accountId2,this.amount);
  }



}
