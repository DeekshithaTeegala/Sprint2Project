import { Component, OnInit } from '@angular/core';
import { WalletAccount } from '../WalletAccount';
import { WalletService } from '../wallet.service';
import { WalletTransactions } from '../WalletTransactions';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-all-accounts',
  templateUrl: './view-all-accounts.component.html',
  styleUrls: ['./view-all-accounts.component.css']
})
export class ViewAllAccountsComponent implements OnInit {

  arr : Observable<WalletAccount[]>;
  arra : WalletAccount[]=[];
  account:WalletAccount=new WalletAccount();
  
  

  constructor(private service : WalletService,private router : Router) {
      service.getAllAccounts().subscribe( data => {this.arra=data;
      console.log(data);this.reloadData();
     })
   }

  
  ngOnInit(): void {
    // this.arr=this.service.getAllAccounts();
  
  }

  reloadData() {
    this.arr=this.service.getAllAccounts();
   this.gotoListWalletAccount();
  }

  
 
  gotoListWalletAccount()
  {
    this.router.navigate(['/view-all-accounts'])
  }

}
